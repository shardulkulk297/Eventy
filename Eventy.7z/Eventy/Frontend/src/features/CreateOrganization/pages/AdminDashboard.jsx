import React from 'react'
import Dashboard from '../components/Dashboard' 

const AdminDashboard = () => {
  return (
    <div><Dashboard /></div>
  )
}

export default AdminDashboard