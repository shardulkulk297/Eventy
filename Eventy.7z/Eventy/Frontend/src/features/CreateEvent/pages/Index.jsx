import React from 'react'

const Index = () => {
  return (
    <div>Index</div>
  )
}

export default Index