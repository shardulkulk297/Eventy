import React from 'react'

const Builder = () => {
  return (
    <div>Builder</div>
  )
}

export default Builder