import React from 'react'
import Dashboard from './pages/Dashboard';
const CreateEvent = () => {
  return (
    <div>
      <Dashboard />
      
    </div>
  )
}

export default CreateEvent
