import React from 'react'

const Hackathons = () => {
  return (
    <div>
        Hackathons
      
    </div>
  )
}

export default Hackathons

