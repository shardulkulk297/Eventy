import React from 'react'

const Host = () => {
  return (
    <div>
      Host 
    </div>
  )
}

export default Host
