import React from 'react'

const Upcoming = () => {
  return (
    <div>
      Upcoming
    </div>
  )
}

export default Upcoming
