import React from 'react';
import FormResponses from '@/components/ui-custom/FormResponses';

const Responses = () => {
  return <FormResponses />;
};

export default Responses;
