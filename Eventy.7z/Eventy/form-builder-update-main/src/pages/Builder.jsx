import React from 'react';
import FormBuilder from '@/components/ui-custom/FormBuilder';

const Builder = () => {
  return <FormBuilder />;
};

export default Builder;
