import React from 'react';
import FormPreview from '@/components/ui-custom/FormPreview';

const Preview = () => {
  return <FormPreview />;
};

export default Preview;
